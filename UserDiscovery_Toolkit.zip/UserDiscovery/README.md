# UserDiscovery Toolkit

This repository contains Windows and Linux user discovery utilities plus a PwnPlug Lite module and a simple web panel.

## Contents
- `windows/UserDiscovery.py` (Python/WMI)
- `windows/UserDiscovery.ps1` (PowerShell/WMI)
- `windows/UserDiscovery-Stealth.ps1` (PowerShell log-only)
- `windows/UserDiscovery.cs` (C# example; requires Newtonsoft.Json)
- `linux/user_discovery_linux.py`
- `pwnplug/pwnplug_user_discovery.py`
- `pwnplug/web/panels/user_discovery.html`
- `docs/UserDiscovery.md` and `docs/UserDiscovery.pdf`

## Quick start
See `docs/UserDiscovery.md`.
