#!/usr/bin/env python3
"""
user_discovery_linux.py
Enumerate local Linux users, groups, and sudo group members.
"""

import json
import pwd
import grp
import subprocess


def get_users():
    return [u.pw_name for u in pwd.getpwall()]


def get_groups():
    return {g.gr_name: g.gr_mem for g in grp.getgrall()}


def get_sudoers():
    # Works on Debian-based systems; adjust group name for other distros if needed.
    for group_name in ("sudo", "wheel"):
        try:
            result = subprocess.check_output(["getent", "group", group_name], stderr=subprocess.DEVNULL)
            members = result.decode().split(":")[3].strip()
            return {"group": group_name, "members": [m for m in members.split(",") if m]}
        except Exception:
            continue
    return {"group": None, "members": []}


def main():
    print(json.dumps({
        "users": get_users(),
        "groups": get_groups(),
        "privileged_group": get_sudoers()
    }, indent=4))


if __name__ == "__main__":
    main()
