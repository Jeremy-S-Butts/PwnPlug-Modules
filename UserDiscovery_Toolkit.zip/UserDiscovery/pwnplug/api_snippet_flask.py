# Flask API snippet
# Add this to your PwnPlug web server (Flask) app:

@app.get("/api/user_discovery")
def api_user_discovery():
    from modules import pwnplug_user_discovery as ud
    return ud.run(silent=True)
