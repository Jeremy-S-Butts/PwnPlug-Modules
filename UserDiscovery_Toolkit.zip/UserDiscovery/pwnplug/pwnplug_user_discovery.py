#!/usr/bin/env python3
"""
PwnPlug Lite Module: User Discovery (Windows via WMI)
Author: Jeremy Shane Butts (CyberGeekJSB)
Logs JSON lines to /opt/pwnplug/logs/user_discovery.json
"""

import os
import json
from datetime import datetime

try:
    import win32com.client
except ImportError:
    win32com = None

LOG = "/opt/pwnplug/logs/user_discovery.json"


def _ensure_dirs():
    os.makedirs(os.path.dirname(LOG), exist_ok=True)


def _log(data: dict):
    _ensure_dirs()
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(data) + "\n")


def _wmi_query(q: str):
    if win32com is None:
        raise RuntimeError("win32com is not available. This module is intended for Windows Python with pywin32 installed.")
    return win32com.client.GetObject("winmgmts:").ExecQuery(q)


def get_users():
    q = "SELECT * FROM Win32_UserAccount WHERE LocalAccount = True ORDER BY Name"
    return [{
        "Name": u.Name,
        "Domain": u.Domain,
        "SID": u.SID,
        "Disabled": u.Disabled,
        "Lockout": u.Lockout,
        "PasswordRequired": u.PasswordRequired,
        "PasswordChangeable": u.PasswordChangeable,
        "PasswordExpires": u.PasswordExpires,
        "Description": u.Description
    } for u in _wmi_query(q)]


def get_hostname():
    cs = _wmi_query("SELECT * FROM Win32_ComputerSystem")
    for c in cs:
        return c.Name
    return "UNKNOWN"


def get_admins():
    comp = get_hostname()
    q = f"""SELECT * FROM Win32_GroupUser
WHERE GroupComponent="Win32_Group.Domain='{comp}',Name='Administrators'"""
    entries = _wmi_query(q)
    members = []
    for e in entries:
        if "Win32_UserAccount" in e.PartComponent:
            members.append(e.PartComponent.split("Name=")[1].replace('"', ''))
    return members


def run(silent: bool = False):
    data = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "hostname": get_hostname(),
        "users": get_users(),
        "administrators": get_admins(),
    }
    _log(data)
    if not silent:
        print(json.dumps(data, indent=4))
    return data


if __name__ == "__main__":
    run(silent=False)
