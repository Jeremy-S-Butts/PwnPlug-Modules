# UserDiscovery-Stealth.ps1
# Writes JSON to a hidden-ish logfile; can be run with -WindowStyle Hidden

$LogFile = "$env:TEMP\.usrdisc.log"

$users = Get-WmiObject Win32_UserAccount | Where-Object { $_.LocalAccount -eq $true }

$admins = (Get-WmiObject Win32_GroupUser |
    Where-Object { $_.GroupComponent -like "*Administrators*" }).PartComponent |
    ForEach-Object { ($_ -split "Name=")[1].Trim('"') }

$result = [PSCustomObject]@{
    Timestamp      = (Get-Date).ToUniversalTime().ToString("o")
    Hostname       = $env:COMPUTERNAME
    Users          = $users
    Administrators = $admins
}

Add-Content -Path $LogFile -Value ($result | ConvertTo-Json -Depth 6)
