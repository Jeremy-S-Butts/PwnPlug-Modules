// UserDiscovery.cs
// Compile-ready example. Requires Newtonsoft.Json.
// csc /r:Newtonsoft.Json.dll UserDiscovery.cs

using System;
using System.Management;
using System.Collections.Generic;
using Newtonsoft.Json;

class UserInfo {
    public string Name { get; set; }
    public string Domain { get; set; }
    public string SID { get; set; }
    public bool Disabled { get; set; }
    public bool PasswordRequired { get; set; }
}

class Program {
    static void Main() {
        List<UserInfo> users = new List<UserInfo>();

        ManagementObjectSearcher u = new ManagementObjectSearcher(
            "SELECT * FROM Win32_UserAccount WHERE LocalAccount=True ORDER BY Name");

        foreach (ManagementObject obj in u.Get()) {
            users.Add(new UserInfo {
                Name = obj["Name"]?.ToString(),
                Domain = obj["Domain"]?.ToString(),
                SID = obj["SID"]?.ToString(),
                Disabled = (bool)(obj["Disabled"] ?? false),
                PasswordRequired = (bool)(obj["PasswordRequired"] ?? false)
            });
        }

        var output = new {
            Timestamp = DateTime.UtcNow.ToString("o"),
            Hostname = Environment.MachineName,
            Users = users
        };

        Console.WriteLine(JsonConvert.SerializeObject(output, Formatting.Indented));
    }
}
