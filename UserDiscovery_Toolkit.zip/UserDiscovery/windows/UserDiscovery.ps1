# UserDiscovery.ps1
# Enumerates local users and local Administrators group members (WMI-based)

$users = Get-WmiObject Win32_UserAccount | Where-Object { $_.LocalAccount -eq $true }

$admins = (Get-WmiObject Win32_GroupUser |
    Where-Object { $_.GroupComponent -like "*Administrators*" }).PartComponent |
    ForEach-Object { ($_ -split "Name=")[1].Trim('"') }

$result = [PSCustomObject]@{
    Hostname       = $env:COMPUTERNAME
    Users          = $users
    Administrators = $admins
}

$result | ConvertTo-Json -Depth 6
