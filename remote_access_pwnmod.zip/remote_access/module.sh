#!/bin/bash
set -euo pipefail

MODULE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$MODULE_DIR/remote_menu.py"

if [[ ! -f "$PY" ]]; then
  echo "[!] Missing: $PY"
  exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "[!] python3 not found. Install: sudo apt update && sudo apt install -y python3"
  exit 1
fi

# Always run as root (this module writes logs under /var/log by default)
if [[ "${EUID}" -ne 0 ]]; then
  exec sudo -E python3 "$PY" "$@"
else
  exec python3 "$PY" "$@"
fi
