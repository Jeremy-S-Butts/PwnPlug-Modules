#!/usr/bin/env python3
"""
PwnPlug Lite - Remote Access Menu Module (Linux/Kali)
- SSH connect
- Telnet client
- RDP via xfreerdp
- Rotating logging

Note: Reverse tunnels / reverse shells are intentionally not included.
"""

import os
import sys
import subprocess
import shutil
import logging
from logging.handlers import RotatingFileHandler
from typing import List, Optional

LOG_DIR = "/var/log/pwnplug_lite"
LOG_FILE = "remote_menu.log"


# ---------------------------------------------------------------------------
# ROOT ELEVATION (Linux)
# ---------------------------------------------------------------------------

def ensure_root():
    """Re-run this script with sudo if we are not root (Linux)."""
    if hasattr(os, "geteuid") and os.geteuid() != 0:
        print("[!] Root privileges required.")
        print("[*] Re-running module with sudo...\n")
        try:
            os.execvp("sudo", ["sudo", sys.executable] + sys.argv)
        except Exception as e:
            print(f"[!] Unable to escalate privileges: {e}")
            sys.exit(1)


# ---------------------------------------------------------------------------
# LOGGING
# ---------------------------------------------------------------------------

def setup_logging(log_dir: str = LOG_DIR, log_file: str = LOG_FILE) -> logging.Logger:
    """Create a rotating file logger."""
    try:
        os.makedirs(log_dir, exist_ok=True)
    except Exception:
        fallback = os.path.expanduser("~/.pwnplug_lite")
        try:
            os.makedirs(fallback, exist_ok=True)
            log_dir = fallback
        except Exception:
            log_dir = "."

    full_path = os.path.join(log_dir, log_file)
    logger = logging.getLogger("pwnplug_remote")
    logger.setLevel(logging.DEBUG)

    if not logger.handlers:
        try:
            handler = RotatingFileHandler(full_path, maxBytes=1024 * 1024, backupCount=5)
        except Exception:
            handler = logging.StreamHandler(sys.stdout)

        formatter = logging.Formatter("%(asctime)s %(levelname)s: %(message)s")
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    logger.debug("Logging initialized, path=%s", full_path)
    return logger


# ---------------------------------------------------------------------------
# HELPERS
# ---------------------------------------------------------------------------

def clear_screen():
    os.system("clear")


def press_enter_to_continue():
    try:
        input("\n[*] Press ENTER to continue...")
    except (EOFError, KeyboardInterrupt):
        pass


def command_exists(cmd: str) -> bool:
    return shutil.which(cmd) is not None


def run_interactive(cmd: List[str], logger: Optional[logging.Logger] = None):
    """Run a foreground interactive command inheriting stdio."""
    try:
        if logger:
            logger.info("Executing interactive command: %s", " ".join(cmd))
        print(f"\n[>] Executing: {' '.join(cmd)}\n")
        rc = subprocess.call(cmd)
        if logger:
            logger.info("Command finished with return code: %s", rc)
    except KeyboardInterrupt:
        if logger:
            logger.warning("Interactive session interrupted by user.")
        print("\n[!] Session interrupted.")
    except Exception as e:
        if logger:
            logger.exception("Error executing command: %s", e)
        print(f"[!] Error executing command: {e}")
    press_enter_to_continue()


def validate_port(port_str: str, default: Optional[str] = None) -> Optional[str]:
    if not port_str:
        return default
    if port_str.isdigit() and 0 < int(port_str) <= 65535:
        return port_str
    return None


def validate_key_path(path: str) -> Optional[str]:
    if not path:
        return None
    expanded = os.path.expanduser(path)
    return expanded if os.path.isfile(expanded) else None


def show_dependency_help():
    print("\n[*] Suggested installs on Kali/Debian:")
    print("    sudo apt update")
    print("    sudo apt install -y openssh-client telnet freerdp2-x11\n")


# ---------------------------------------------------------------------------
# MENU OPTIONS
# ---------------------------------------------------------------------------

def option_1_ssh_connect(logger: logging.Logger):
    clear_screen()
    print("=== SSH CONNECT ===\n")

    if not command_exists("ssh"):
        print("[!] Missing binary: ssh (openssh-client)")
        show_dependency_help()
        press_enter_to_continue()
        return

    target = input("Target IP / Hostname: ").strip()
    user = input("Username (blank = current user): ").strip()
    port = input("Port [22]: ").strip()
    keypath = input("Private key file (optional): ").strip()

    if not target:
        print("[!] Target required.")
        press_enter_to_continue()
        return

    port = validate_port(port, default="22")
    if port is None:
        print("[!] Invalid port specified.")
        press_enter_to_continue()
        return

    key_valid = validate_key_path(keypath) if keypath else None
    if keypath and not key_valid:
        print(f"[!] Key file not found: {keypath}")
        press_enter_to_continue()
        return

    dest = f"{user}@{target}" if user else target
    cmd = ["ssh", "-p", port]
    if key_valid:
        cmd += ["-i", key_valid]
    cmd += [dest]

    logger.info("SSH connect: dest=%s user=%s port=%s key=%s",
                target, user or "(current)", port, key_valid or "(none)")
    run_interactive(cmd, logger=logger)


def option_2_telnet(logger: logging.Logger):
    clear_screen()
    print("=== TELNET SESSION ===\n")

    if not command_exists("telnet"):
        print("[!] Missing binary: telnet")
        show_dependency_help()
        press_enter_to_continue()
        return

    host = input("Target Host: ").strip()
    if not host:
        print("[!] Target Host required.")
        press_enter_to_continue()
        return

    port = input("Port [23]: ").strip()
    port = validate_port(port, default="23")
    if port is None:
        print("[!] Invalid port specified.")
        press_enter_to_continue()
        return

    cmd = ["telnet", host, port]
    logger.info("Telnet: host=%s port=%s", host, port)
    run_interactive(cmd, logger=logger)


def option_3_rdp(logger: logging.Logger):
    clear_screen()
    print("=== RDP (xfreerdp) ===\n")

    if not command_exists("xfreerdp"):
        print("[!] xfreerdp not installed.")
        show_dependency_help()
        press_enter_to_continue()
        return

    target = input("Target IP/Hostname: ").strip()
    user = input("Username: ").strip()
    domain = input("Domain (optional): ").strip()
    width = input("Width [1280]: ").strip() or "1280"
    height = input("Height [720]: ").strip() or "720"

    if not (target and user):
        print("[!] Missing required fields (target and username).")
        press_enter_to_continue()
        return

    if not (width.isdigit() and height.isdigit()):
        print("[!] Width and Height must be numbers.")
        press_enter_to_continue()
        return

    cmd = ["xfreerdp", f"/v:{target}", f"/u:{user}", f"/size:{width}x{height}"]
    if domain:
        cmd.append(f"/d:{domain}")

    logger.info("RDP: target=%s user=%s domain=%s size=%sx%s",
                target, user, domain or "(none)", width, height)
    run_interactive(cmd, logger=logger)


def option_4_dependency_checker(logger: logging.Logger):
    clear_screen()
    print("=== DEPENDENCY CHECKER ===\n")

    checks = [
        ("ssh", "openssh-client"),
        ("telnet", "telnet"),
        ("xfreerdp", "freerdp2-x11"),
    ]

    missing = []
    for binary, pkg in checks:
        if command_exists(binary):
            print(f"[+] Found: {binary}")
            logger.info("Dependency found: %s", binary)
        else:
            print(f"[-] Missing: {binary} (package: {pkg})")
            logger.warning("Dependency missing: %s (pkg=%s)", binary, pkg)
            missing.append(pkg)

    if missing:
        print("\n[*] Install missing packages:")
        print("    sudo apt update")
        print("    sudo apt install -y " + " ".join(sorted(set(missing))))

    press_enter_to_continue()


def option_5_quit(logger: logging.Logger):
    clear_screen()
    logger.info("Quit selected.")
    print("[*] Closing Remote Access Module.\n")
    sys.exit(0)


# ---------------------------------------------------------------------------
# MAIN MENU
# ---------------------------------------------------------------------------

def print_banner():
    print(r"""
=========================================
      PwnPlug Lite - Remote Access
=========================================
""")


def print_menu():
    print("Select an option:\n")
    print("  [1] SSH Connect")
    print("  [2] Telnet (system client)")
    print("  [3] RDP (xfreerdp)")
    print("  [4] Dependency Checker")
    print("  [5] Quit\n")


def main():
    ensure_root()
    logger = setup_logging()

    while True:
        clear_screen()
        print_banner()
        print_menu()

        try:
            choice = input("PwnPlug-Remote> ").strip()
        except (EOFError, KeyboardInterrupt):
            logger.info("Exiting due to EOF/KeyboardInterrupt.")
            print("\n[*] Exiting.")
            sys.exit(0)

        if choice == "1":
            option_1_ssh_connect(logger)
        elif choice == "2":
            option_2_telnet(logger)
        elif choice == "3":
            option_3_rdp(logger)
        elif choice == "4":
            option_4_dependency_checker(logger)
        elif choice == "5":
            option_5_quit(logger)
        else:
            print("[!] Invalid choice.")
            logger.warning("Invalid menu choice: %s", choice)
            press_enter_to_continue()


if __name__ == "__main__":
    main()
